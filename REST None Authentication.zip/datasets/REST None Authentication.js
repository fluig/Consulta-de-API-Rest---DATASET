function createDataset(fields, constraints, sortFields) {
	var dataset = DatasetBuilder.newDataset();
	try{
	    var clientService = fluigAPI.getAuthorizeClientService();
	    var data = {                                                   
	        companyId : getValue("WKCompany") + '',
	        serviceCode : 'correios',                     
	        endpoint : '/cep/02022020',  
	        method : 'get',                                        
	    }                                                          
	    var vo = clientService.invoke(JSON.stringify(data));
	 
	    if(vo.getResult()== null || vo.getResult().isEmpty()){
	        throw new Exception("Retorno está vazio");
	    }else{
	        log.info(vo.getResult());
	        
	        dataset.addColumn("CEP");
	        dataset.addColumn("Tipo de Logradouro");
	        dataset.addColumn("Logradouro");
	        dataset.addColumn("Bairro");
	        dataset.addColumn("Cidade");
	        dataset.addColumn("Estado");

	        var json = JSON.parse(vo.getResult());
	    	
	    	dataset.addRow([json.cep, json.tipoDeLogradouro, json.logradouro,
	    					json.bairro, json.cidade, json.estado]);
	    }
	} catch(err) {
	    throw new Exception(err);
	}
	return dataset;
}